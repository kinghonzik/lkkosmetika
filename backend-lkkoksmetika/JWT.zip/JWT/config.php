
<?php
    class Config {
        
        // Static variable and static function
        // using static keyword
        public static $authSecret = "2022lk*@#(&)kosmetika^^^tralalala@!juhuuuuu85žral0k";
        public static $authExpirationSeconds = 60 * 60;
        public static $jwtHeader = array('alg'=>'HS256','typ'=>'JWT');
    }
?>