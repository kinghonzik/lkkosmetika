<?php

$docUrl = 'https://roytuts.com/how-to-generate-and-validate-jwt-using-php-without-using-third-party-api/';